# Activate the required libraries
library(readr)
library(ggplot2)

# Read in the single profile data
df <- read_csv("SR04.csv")

# Plot the temperature against depth and flip the y axis
ggplot(df) +
  geom_path(aes(temp, z)) +
  scale_y_reverse()
